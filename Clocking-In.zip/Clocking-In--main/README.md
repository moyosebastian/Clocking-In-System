# Clocking-In-
This system allows me to record my working hours every day. It automatically detects the day of the week using the computer’s real calendar and applies different pay rates depending on whether I’m working on weekdays, Saturdays, Sundays, or night shifts.
